const routes = {
  root: '/',
  settings: '/settings',
  authentication: '/authentication',
  users: '/all_users',
  usersProfile: '/user/:id',
}

export default routes
