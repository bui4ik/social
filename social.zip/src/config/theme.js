const theme = {}

export default theme
