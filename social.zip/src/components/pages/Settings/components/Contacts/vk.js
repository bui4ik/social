import React from 'react'
import { Field } from 'react-final-form'

const Vk = () => (
  <div>
    <label>Vk</label>
    <Field name="contacts.vk" component="input" placeholder="url" />
  </div>
)

export default Vk
