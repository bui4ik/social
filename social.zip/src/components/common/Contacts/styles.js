import styled from 'styled-components'

export const Contacts = styled.div`
  display: flex;
`
export const ContactsItem = styled.a`
  color: #9fa8da;
  margin-right: 20px;
  cursor: pointer;
`
